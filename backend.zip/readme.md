Extract the backend.zip 
cd backend
npm install
npm run preview