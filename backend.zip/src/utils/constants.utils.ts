export const COUNTRIES = {
  INDIA: "india",
  SRI_LANKA: "srilanka",
};